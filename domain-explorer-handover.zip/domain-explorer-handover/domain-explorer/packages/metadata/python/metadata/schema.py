"""Pydantic v2 schemas for the Domain Explorer metadata registry.

The shapes mirror packages/metadata/src/schema.ts (Zod) so the same YAML
files validate identically in both ecosystems.
"""
from enum import Enum
from typing import Any, Dict, Literal, Union

from pydantic import BaseModel, ConfigDict, Field


class Vertical(str, Enum):
    BFSI = "BFSI"
    INSURANCE = "Insurance"
    RETAIL = "Retail"
    RCG = "RCG"
    CPG = "CPG"
    TTH = "TTH"
    MANUFACTURING = "Manufacturing"
    LIFE_SCIENCES = "LifeSciences"
    HEALTHCARE = "Healthcare"
    TELECOM = "Telecom"
    MEDIA = "Media"
    ENERGY = "Energy"
    UTILITIES = "Utilities"
    PUBLIC_SECTOR = "PublicSector"
    HI_TECH = "HiTech"
    PROFESSIONAL_SERVICES = "ProfessionalServices"
    CROSS_CUTTING = "CrossCutting"


KpiDirection = Literal["higher_is_better", "lower_is_better", "target_band"]
PersonaLevel = Literal["C-suite", "VP", "Director", "Manager", "IC"]
ConnectorLatency = Literal["realtime", "near-realtime", "batch"]
ConnectorMode = Literal["push", "pull", "stream", "file"]
RelationshipKind = Literal["one_to_one", "one_to_many", "many_to_one", "many_to_many"]


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class Persona(_Strict):
    name: str = Field(..., min_length=1)
    title: str = Field(..., min_length=1)
    level: PersonaLevel


class Decision(_Strict):
    id: str = Field(..., min_length=1)
    statement: str = Field(..., min_length=1)


class Kpi(_Strict):
    id: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1)
    formula: str = Field(..., min_length=1)
    unit: str = Field(..., min_length=1)
    direction: KpiDirection
    decisionsSupported: list[str] = Field(default_factory=list)


class EntityAttribute(_Strict):
    name: str = Field(..., min_length=1)
    type: str = Field(..., min_length=1)
    description: str | None = None
    isPrimaryKey: bool | None = None
    isForeignKey: bool | None = None
    references: str | None = None


class EntityRelationship(_Strict):
    to: str = Field(..., min_length=1)
    kind: RelationshipKind
    via: str | None = None


class Entity(_Strict):
    name: str = Field(..., min_length=1)
    description: str | None = None
    keys: list[str] = Field(default_factory=list)
    attributes: list[EntityAttribute] = Field(default_factory=list)
    relationships: list[EntityRelationship] = Field(default_factory=list)


class DataModelArtifacts(_Strict):
    threeNF: str | None = None
    vault: str | None = None
    dimensional: str | None = None


class DataModelRelationship(_Strict):
    """Cardinality edge between two entities, declared at the data-model level.

    `from` is a Python keyword, so the field is `from_` with a `from` alias.
    """

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, populate_by_name=True)

    from_: str = Field(..., min_length=1, alias="from")
    to: str = Field(..., min_length=1)
    kind: RelationshipKind


class DataModel(_Strict):
    entities: list[Entity] = Field(default_factory=list)
    relationships: list[DataModelRelationship] = Field(default_factory=list)


class Standard(_Strict):
    """An external standard or protocol a subdomain depends on."""

    id: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1)
    version: str | None = None
    url: str | None = None


class SourceSystem(_Strict):
    vendor: str = Field(..., min_length=1)
    product: str = Field(..., min_length=1)
    category: str = Field(..., min_length=1)


class Connector(_Strict):
    type: str = Field(..., min_length=1)
    protocol: str = Field(..., min_length=1)
    auth: str = Field(..., min_length=1)
    typicalSources: list[str] = Field(default_factory=list)


class Subdomain(_Strict):
    id: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1)
    vertical: Vertical
    oneLiner: str = Field(..., min_length=1)
    personas: list[Persona] = Field(..., min_length=1)
    decisions: list[Decision] = Field(default_factory=list)
    kpis: list[Kpi] = Field(default_factory=list)
    dataModel: DataModel = Field(default_factory=DataModel)
    dataModelArtifacts: DataModelArtifacts | None = None
    sourceSystems: list[SourceSystem] = Field(default_factory=list)
    connectors: list[Connector] = Field(default_factory=list)
    ingestionChallenges: list[Union[str, Dict[str, Any]]] = Field(default_factory=list)
    integrationChallenges: list[Union[str, Dict[str, Any]]] = Field(default_factory=list)
    standards: list[Standard] = Field(default_factory=list)
    glossaryTerms: list[str] = Field(default_factory=list)


class KpiRegistryEntry(Kpi):
    vertical: Vertical


class KpiMasterEntry(_Strict):
    id: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1)
    formula: str = Field(..., min_length=1)
    unit: str = Field(..., min_length=1)
    direction: KpiDirection
    definition: str | None = None
    vertical: Vertical | None = None
    subdomains: list[str] = Field(default_factory=list)
    related_personas: list[str] = Field(default_factory=list)
    decisionsSupported: list[str] = Field(default_factory=list)


class KpiSqlSpec(_Strict):
    kpi_id: str = Field(..., min_length=1)
    threeNF: str | None = None
    vault: str | None = None
    dimensional: str | None = None
    notes: str | None = None


class SourceSystemEntry(_Strict):
    id: str = Field(..., min_length=1)
    vendor: str = Field(..., min_length=1)
    product: str = Field(..., min_length=1)
    category: str = Field(..., min_length=1)
    primaryConnectors: list[str] = Field(default_factory=list)


class ConnectorPattern(_Strict):
    id: str = Field(..., min_length=1)
    type: str = Field(..., min_length=1)
    protocol: str = Field(..., min_length=1)
    auth: str = Field(..., min_length=1)
    typicalSources: list[str] = Field(default_factory=list)
    latency: ConnectorLatency
    modes: list[ConnectorMode] = Field(default_factory=list)
    # Directory of the runnable Python stub for this pattern, when one exists.
    stubPath: str | None = None
